
  # Bistro Cloud Ordering Platform

  This is a code bundle for Bistro Cloud Ordering Platform. The original project is available at https://www.figma.com/design/TVdHmKR4OZUwS2HGx7dnp5/Bistro-Cloud-Ordering-Platform.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  